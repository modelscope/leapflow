# Copyright (c) Alibaba, Inc. and its affiliates.
"""User-facing configuration control plane for LeapFlow."""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, fields, replace
from getpass import getpass
from pathlib import Path
from types import UnionType
from typing import Any, Literal, Union, get_args, get_origin, get_type_hints

import yaml

from leapflow.config import Settings
from leapflow.security.secrets import ScopedSecretResolver, secret_ref, secret_scope

ConfigScope = Literal["profile", "workspace", "user"]
SecretScope = Literal["profile", "global"]


@dataclass(frozen=True)
class ConfigFieldSpec:
    """Writable config field contract."""

    key: str
    section: str
    name: str
    value_type: Any
    profile_file: str
    setting_name: str | None = None
    scopes: tuple[ConfigScope, ...] = ("profile", "workspace")
    secret: bool = False
    ref_name: str | None = None
    category: str = "Runtime"
    description: str = ""
    value_hint: str = ""
    hot_reload: str = "yes"
    examples: tuple[str, ...] = ()


@dataclass(frozen=True)
class ConfigMutationResult:
    """Result of a config mutation."""

    ok: bool
    message: str
    changed_keys: tuple[str, ...] = ()
    path: Path | None = None
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True)
class ConfigValueView:
    """Rendered config value with source metadata."""

    key: str
    value: str
    source: str = "effective"
    secret: bool = False


@dataclass(frozen=True)
class ConfigFieldView:
    """Human-readable field metadata for config discovery."""

    key: str
    value: str
    value_type: str
    category: str
    scopes: tuple[str, ...]
    hot_reload: str
    secret: bool
    description: str
    value_hint: str = ""
    examples: tuple[str, ...] = ()


@dataclass(frozen=True)
class ConfigSnapshot:
    """A redacted snapshot of user-facing configuration."""

    values: tuple[ConfigValueView, ...]
    sources: tuple[str, ...]
    warnings: tuple[str, ...] = ()


_BOOTSTRAP_ONLY_SETTINGS = frozenset(
    {
        "data_dir",
        "profile",
        "workspace_root",
        "layout",
        "profile_layout",
        "profile_manifest",
        "config_sources",
        "watched_config_paths",
        "config_warnings",
        "duckdb_path",
        "runtime_dir",
        "audit_log_path",
        "skills_dir",
        "visual_frame_cache_dir",
        "video_cache_dir",
        "perceptual_field_config",
    }
)

_SECRET_SETTINGS = frozenset(
    {"llm_api_key", "vlm_api_key", "llm_aux_api_key", "compression_api_key"}
)

_FIELD_DESCRIPTIONS = {
    "benchmark.commands": (
        "JSON object mapping external benchmark ids to explicitly approved command templates. "
        "The harness never downloads, installs, or invents commands."
    ),
    "benchmark.data_roots": (
        "JSON object mapping benchmark ids to licensed local dataset roots used by external adapters."
    ),
    "benchmark.license_acceptances": (
        "JSON object recording operator-accepted benchmark license identifiers."
    ),
    "benchmark.hardware_profiles": (
        "JSON object mapping Tier4 device ids to operator-approved zero_motion preflight profiles. "
        "Each profile requires preflight_mode='zero_motion' and a command that emits the "
        "manifest-required JSON report; real motion still requires separate approval gates."
    ),
    "mcp.approval_mode": (
        "Approval policy for tools from external MCP servers, which run third-party code "
        "with this agent's privileges. mutating_only assesses every tool that does not "
        "declare itself read-only; always assesses and audits all of them, including "
        "declared reads; off disables the gate entirely. Read when MCP servers are "
        "configured, so a change needs a daemon restart."
    ),
    "hardware.enabled": (
        "Passive local hardware discovery is on by default: host metrics plus camera and "
        "microphone enumeration. Enumeration opens nothing; privacy-gated reads still "
        "require approval. Set false only to hard-disable the subsystem. Takes effect "
        "after `leap daemon restart` because the approval classifier is composed when "
        "the orchestrator is built."
    ),
    "hardware.devices_dir": (
        "Directory of device declaration files for the active profile. Read once at "
        "startup, so a change needs a daemon restart."
    ),
    "hardware.providers": (
        "Comma-separated discovery sources, e.g. 'yaml,host,media'. Empty uses all "
        "three passive local sources: declarations, host resources, and media enumeration. "
        "Cameras/microphones are listed but never opened until an approved preview. "
        "Scanners that transmit or leave the host are opt-in and must be named here. "
        "Providers run at startup, so a change needs a daemon restart."
    ),
    "hardware.fleet_nodes": (
        "JSON array of named LHP edge nodes. Connections and heartbeat supervision are "
        "assembled at startup, so a change needs a daemon restart."
    ),
    "hardware.alert_policies": (
        "JSON array of hardware event-to-action rules. Empty disables alert reflexes; "
        "hw_estop rules halt directly while other actions use approval. Stream sources "
        "bind these rules at startup, so a change needs a daemon restart."
    ),
    "hardware.host_interval_s": (
        "Seconds between samples of fast host channels (cpu, memory, network); disk, "
        "battery and thermal channels sample less often. 0 uses the 5s default. Read "
        "when sampling starts, so a change needs a daemon restart."
    ),
    "hardware.host_include": (
        "Channel-id prefixes to keep from the discovered host set, e.g. 'cpu,memory'. "
        "Empty keeps everything discovered. Applied at discovery, so a change needs a "
        "daemon restart."
    ),
    "hardware.host_exclude": (
        "Channel-id prefixes to drop from the discovered host set, e.g. 'net.utun'. "
        "Applied after include, at discovery, so a change needs a daemon restart."
    ),
    "hardware.rediscover_interval_s": (
        "Seconds between automatic rediscovery passes, so a peripheral attached after "
        "startup appears without a restart. 0 disables it and leaves rediscovery to "
        "`leap hw scan`. Runs on the monitor cadence, never during a turn."
    ),
    "hardware.media_screens": (
        "Enumerate displays as previewable devices. Off by default, because a platform "
        "that presents the screen as another video input would put 'stream this screen' "
        "beside the webcam. Reads still require consent. Applied at discovery, so a "
        "change needs a daemon restart."
    ),
    "hardware.media_microphones": (
        "Enumerate microphones alongside cameras. Only an input level is exposed, never "
        "audio. Applied at discovery, so a change needs a daemon restart."
    ),
    "hardware.media_exclude_usb": (
        "Comma-separated USB identities ('vid' or 'vid:pid', hex) whose video nodes a "
        "dedicated driver owns, e.g. '8086' for RealSense UVC endpoints. They are not "
        "listed as generic cameras, so nothing offers a second opener of that hardware. "
        "Linux only; applied at discovery, so a change needs a daemon restart."
    ),
    "hardware.preview_max_fps": (
        "Hard capture ceiling for page-selected economy/balanced/detail profiles. The "
        "default balanced profile is 8fps; this 12fps ceiling is also declared at media "
        "discovery, so a change needs a daemon restart."
    ),
    "hardware.preview_max_width": (
        "Hard scaled-width ceiling for the page-selected preview profiles; height follows "
        "aspect ratio. Balanced requests 960px below the 1280px default ceiling. Read "
        "when the preview broker is built, so a change needs a daemon restart."
    ),
    "hardware.preview_quality": (
        "Hard JPEG-quality ceiling (1-100) for page-selected preview profiles. Balanced "
        "uses 75 below the default ceiling of 85. Read when the preview broker is built, "
        "so a change needs a daemon restart."
    ),
    "hardware.preview_idle_timeout_s": (
        "How long a device stays claimed after the last preview viewer disconnects. "
        "Short by design: a camera left on after everyone stopped looking is the failure "
        "this subsystem exists to prevent. Read when the preview broker is built, so a "
        "change needs a daemon restart."
    ),
    "hardware.max_devices": (
        "Maximum number of devices admitted from all providers. Applied during "
        "admission at startup; changing it needs a daemon restart."
    ),
    "hardware.unverified_policy": (
        "How to treat a device context no human has confirmed. deny_write keeps it "
        "readable but not commandable. Applied during admission, so a change needs a "
        "daemon restart."
    ),
    "hardware.require_describe": (
        "Require hw_describe before the first command to a device, so the model has "
        "read the channel's operating envelope before commanding it. Read at startup; "
        "a change needs a daemon restart."
    ),
    "hardware.envelope_grant": (
        "Let one consent cover a channel's whole declared envelope band. Off asks for "
        "every command separately. Read at startup, so a change needs a daemon restart."
    ),
    "hardware.trust_skip_enabled": (
        "Let reversible channels with VERIFIED+ trust skip per-command approval. "
        "Off by default; irreversible channels always require approval regardless. "
        "Read at startup, so a change needs a daemon restart."
    ),
    "hardware.write_verification_follow_s": (
        "How long a post-write verdict may follow a value that is still travelling "
        "toward its command before reporting 'pending'. A declared settling time says "
        "when an observation becomes meaningful, not when a servo has arrived, so a "
        "slow move judged by it alone looks contradicted. Read when the verification "
        "coordinator is built, so a change needs a daemon restart."
    ),
    "hardware.stream_enabled": (
        "Sample channels that declare a sample rate. Sampling loops start during "
        "initialization, so a change needs a daemon restart."
    ),
    "hardware.stream_ring_capacity": (
        "Per-channel raw sample ring buffer depth. Buffers are sized when sampling "
        "starts, so a change needs a daemon restart."
    ),
    "hardware.persist_readings": (
        "Persist sampled readings so physical history survives the process. Off means "
        "samples exist only in memory and nothing can be learned from them afterwards. "
        "Read when sampling starts, so a change needs a daemon restart."
    ),
    "hardware.downsample_interval_s": (
        "Seconds of samples collapsed into one stored history window. Read when sampling "
        "starts, so a change needs a daemon restart."
    ),
    "hardware.raw_retention_days": (
        "How long raw sample files are kept. They are session-scoped, sensitive, and "
        "never synced. Read when sampling starts, so a change needs a daemon restart."
    ),
    "hardware.history_retention_days": (
        "How long downsampled history windows are kept in instrument.duckdb. Longer than "
        "the raw tier because this is the data later analysis reads, but bounded: nothing "
        "else deletes from that table. Read when sampling starts, so a change needs a "
        "daemon restart."
    ),
    "hardware.raw_segment_mb": (
        "Size at which a raw sample file is closed and a new segment started. A finished "
        "segment is written once, so its indexed size and TTL are accurate and old data "
        "can expire without touching the file being appended to. Read when sampling "
        "starts, so a change needs a daemon restart."
    ),
    "hardware.reading_store_sensitive": (
        "Register the durable instrument.duckdb history tier as sensitive and "
        "non-syncable, so a profile backup excludes physical series that may carry a "
        "trade secret or sample information. On by default; opt out only for a bench "
        "known to produce no sensitive data. Applied when the store is built, so a "
        "change needs a daemon restart."
    ),
    "hardware.skills_enabled": (
        "Comma-separated patterns (fnmatch) of node skills a hardware node offers; empty "
        "offers every discovered skill. Read when the node starts, so a change needs a "
        "node restart."
    ),
    "hardware.skills_speed_pct_max": (
        "Upper bound on the speed rate (percent of firmware maximum) any skill plan may "
        "request. Read when the node starts, so a change needs a node restart."
    ),
    "hardware.skills_max_duration_s": (
        "Longest one skill execution may run before the node halts it and reports a "
        "timeout. Read when the node starts, so a change needs a node restart."
    ),
    "hardware.skills_plan_ttl_s": (
        "How long a skill plan the node computed stays executable; an older plan must be "
        "planned (and approved) again. Read when the node starts, so a change needs a node "
        "restart."
    ),
    "hardware.skills_halt_timeout_s": (
        "Longest one actuator's halt call may take when a run is stopped or fails before "
        "the node logs it as failed. Read when the node starts, so a change needs a node "
        "restart."
    ),
    "hardware.skills_stop_grace_s": (
        "How long a stopped skill may unwind on its own before the node cancels it. Read "
        "when the node starts, so a change needs a node restart."
    ),
    "hardware.skills_dispatch_settle_s": (
        "How long the node waits for a write still inside a transport when a run ends; "
        "past it the run reports side effect UNKNOWN and keeps its devices held until the "
        "write resolves. Read when the node starts, so a change needs a node restart."
    ),
    "hardware.skills_episode_fps": (
        "Rate at which every executed skill run is recorded (arm state, commands, one "
        "frame per workcell camera) under the profile's hardware/episodes for offline "
        "training; 0 disables recording. Read when the node starts, so a change needs a "
        "node restart."
    ),
    "hardware.skills_episode_min_free_mb": (
        "Free disk space below which a run is not recorded (the run itself proceeds). "
        "Read when the node starts, so a change needs a node restart."
    ),
    "hardware.share_frames": (
        "Let the model look at workcell camera frames (perceive.snapshot). Off by default; "
        "the workcell must also declare share_frames. Each shared frame is audited and "
        "shown to the model only for the current turns, never persisted. Read when the "
        "skill tools are built, so a change needs a daemon restart."
    ),
    "llm.api_key": "Primary LLM API key stored in the local secret vault.",
    "llm.aux_api_key": "Auxiliary LLM provider API key stored in the local secret vault.",
    "llm.base_url": "OpenAI-compatible endpoint for the primary LLM provider.",
    "llm.model": "Primary LLM model used by chat, planning, and tool reasoning.",
    "llm.context_length": "Runtime context budget in tokens shown in the TUI status bar.",
    "llm.max_retries": "Retry attempts for transient LLM provider failures.",
    "vlm.api_key": "VLM API key stored in the local secret vault.",
    "runtime.mock_host": "Use the in-process mock host when native OS control is unavailable.",
    "runtime.log_level": "Logging verbosity for CLI, TUI, and runtime diagnostics.",
    "memory.working_max_tokens": (
        "Working-memory token budget injected into active reasoning; 0 automatically "
        "scales with the model context window, while a positive value is a hard cap."
    ),
    "visual.track_enabled": "Enable screenshot-based visual perception for the active profile.",
    "recording.mode": "Default recording pipeline used during teaching and observation.",
    "scheduler.tick_seconds": "Scheduler polling interval in seconds.",
    "scheduler.agent_max_iterations": "Iteration budget cap for agent-mode scheduled tasks (bounded tool loop).",
    "scheduler.agent_tool_blocklist": "Comma-separated tool names blocked during agent-mode scheduled execution (e.g. schedule_reentry to prevent recursive scheduling).",
    "scheduler.default_max_retries": "Default retry attempts for failed scheduled tasks. Applied when arm() does not specify per-task retries. 0 disables retry.",
    "scheduler.default_retry_backoff_s": "Base backoff interval in seconds for exponential retry delay (backoff_s * 2^attempt). Applied when arm() does not specify per-task backoff.",
    "scheduler.delivery_enabled": "Enable post-execution result delivery to a gateway platform (opt-in, default off).",
    "dashboard.enabled": "Enable the local monitoring web dashboard.",
    "dashboard.bind": "Address the dashboard web server binds to (keep loopback).",
    "dashboard.port": "TCP port for the local dashboard web server.",
    "dashboard.auto_open": "Open the default browser automatically when launching the dashboard.",
    "dashboard.token_ref": "Secret ref for the local dashboard access token.",
    "stream.output": "Stream assistant tokens and progress in interactive sessions.",
    "verbose.progress": "Show inline execution progress for tools and runtime steps.",
    "agent.iter_floor": "Baseline iteration cap per task; the adaptive loop starts here and widens with difficulty.",
    "agent.iter_ceiling": "Maximum iterations a hard task can earn via adaptive-depth (difficulty-scaled) budget widening, before any progress-gated extension.",
    "agent.budget_scale_k": "Slope mapping task difficulty [0,1] to iterations between the floor and ceiling.",
    "agent.iter_hard_cap": "Absolute iteration backstop. A productively-unfinished task (open ledger questions + ongoing progress, within resource limits) extends past the elastic ceiling toward this cap, so long tasks are bounded by progress/resources rather than a fixed count.",
    "agent.iter_extension_step": "Iterations granted per progress-gated extension when the elastic ceiling is reached and the task is still productively unfinished.",
    "agent.stall_rounds": "Consecutive no-progress rounds (no new ledger findings/questions or evidence) after which budget extension stops and the loop is allowed to converge.",
    "recovery.turn_deadline_s": "Wall-clock deadline (seconds) for recovery attempts within one agent turn; 0 = unlimited so a long-running task is never denied recovery for a late transient error (the action-count budget remains the bound).",
    "recovery.total_actions": "Maximum total recovery actions (retries/transforms/failovers) within one agent turn before recovery halts.",
    "recovery.max_retry_per_category": "Maximum recovery retries per error category within one agent turn.",
    "guardrail.enabled": "Enable tool-loop guardrails (repetition / stagnation / single-tool domination). Progress-aware: halts and finalize nudges are suppressed while the task is still making progress, so long productive tasks are not cut short.",
    "approval.advisory_risk_enabled": (
        "Surface the auxiliary LLM risk score as an advisory line in human approval "
        "prompts. The score is informational only — it cannot auto-approve, auto-deny, "
        "or lower the deterministic risk level. Disabling skips the auxiliary call "
        "entirely. Hot-reloadable."
    ),
    "guardrail.max_repeats": "Consecutive identical tool calls (same name + arguments) that trigger a loop halt — only when the task is also stalled.",
    "guardrail.max_consecutive_same": "Consecutive uses of the same tool that trigger a diversify nudge (suppressed while progressing, so batch/sequential work is not penalized).",
    "guardrail.stagnation_window": "Window of recent genuine tool results over which the low-success-rate stagnation warning is computed.",
    "guardrail.min_success_rate": "Minimum tool success rate within the stagnation window before a stagnation warning is emitted.",
    "guardrail.max_calls_per_turn": "Hard ceiling on total tool invocations in a single agent turn; exceeding it halts unconditionally regardless of progress.",
    "tools.ripgrep_autoinstall": "Best-effort seamless ripgrep auto-install for code_search when missing (macOS/Homebrew, no sudo, background, non-fatal). code_search always works via the pure-Python fallback regardless; disabling this just skips the accelerator install and shows a manual hint.",
    "tools.test_command": "Explicit command for the test_run tool (empty => auto-detect pytest/npm/go/cargo from project markers).",
    "tools.lint_command": "Explicit command for the lint_check tool (empty => auto-detect ruff/eslint/go vet/clippy from project markers).",
    "tools.terminal_session_enabled": "Enable persistent terminal sessions (terminal_open/send/read/close/list). Off by default: a persistent shell runs arbitrary interactive input; enabling is the operator opt-in. Sessions are bounded (max count, idle TTL) with process-group cleanup.",
    "tools.verify_edits": "After edit_file/file_write, run an advisory syntax check on the written file (Python via AST) and attach syntax_ok/syntax_error to the result. Advisory only — it never blocks the write; the model sees a broken edit immediately and can fix it.",
    "agent.validate_tool_args": "Validate a tool call's required arguments before execution; a missing required parameter returns a structured invalid_arguments result (with the accepted schema) for in-turn self-repair instead of an opaque handler error. Does not count as a failure and never trips the batch-stop gate.",
    "daemon.max_concurrent_turns": "Maximum agent turns the daemon runs concurrently across sessions (Stage 3). 3 (default) lets several fresh TUI sessions run in parallel on isolated per-session engines; set to 1 for strict serialized fallback. Changes require `leap daemon restart`.",
    "daemon.log_level": "File-log verbosity for the leapd process (written to leapd.log). Independent from runtime.log_level so daemon field diagnostics (deferred init progress, turn usage, empty-response warnings) are captured without making the CLI/TUI noisy. Changes require `leap daemon restart`.",
    "daemon.max_live_sessions": "Maximum per-session execution contexts the daemon keeps live (bounds memory); the least-recently-active non-primary session is evicted beyond this. Changes require `leap daemon restart`.",
    "daemon.session_idle_ttl_s": "Idle seconds after which a non-primary session execution context is evicted (0 disables idle eviction). Changes require `leap daemon restart`.",
    "daemon.request_ledger_max_entries": "Maximum RPC request ids the daemon remembers for idempotency (bounds memory); the oldest entries are dropped beyond this. Changes require `leap daemon restart`.",
    "daemon.request_ledger_ttl_s": "Seconds a completed RPC request id stays in the idempotency ledger, so a client retry is deduplicated instead of re-running the turn. Changes require `leap daemon restart`.",
    "agent.cost_ceiling_context_multiple": "Optional cumulative effective-cost ceiling as a multiple of context length (0 disables; a soft finalize nudge, the iteration cap stays the hard bound).",
    "agent.subagent_max_depth": "Maximum delegation depth for subagents (governs recursive task decomposition).",
    "agent.max_parallel_tools": "Maximum tool calls executed in parallel within a single LLM response's batch (metadata-classified read-only / non-overlapping idempotent tools). Bounds the asyncio.gather fan-out so a large batch does not overwhelm IO; 1 forces sequential execution.",
    "agent.subagent_max_concurrent": "Maximum concurrent child subagents per delegation batch.",
    "agent.subagent_max_iterations": "Iteration budget for each delegated subagent's tool loop.",
    "agent.subagent_full_loop": "Run delegated subagents through the engine's full adaptive OODA loop on an isolated child frame (progressive disclosure, compression, recovery, research ledger) instead of the lightweight loop; state-isolated and depth-gated (default off).",
    "agent.calibration_enabled": "Enable S3-L3 online difficulty calibration: apply the offline S3-L2 report's bounded suggested weight scale to the difficulty->budget sensitivity (scale_k), derived from the baseline and clamped/reversible (default off).",
    "agent.calibration_min_confidence": "Minimum calibration-report confidence required before an online difficulty-weight adjustment is applied (guards against acting on thin data).",
    "agent.calibration_interval_turns": "Re-run online difficulty/threshold calibration every N root turns as outcome data accumulates (0 = one-shot at startup only; requires calibration enabled).",
    "agent.calibration_difficulty_min_k": "Operator floor for calibrated difficulty scaling, clamped by the built-in safety envelope.",
    "agent.calibration_difficulty_max_k": "Operator ceiling for calibrated difficulty scaling, clamped by the built-in safety envelope.",
    "agent.calibration_finalizing_min_ratio": "Operator floor for calibrated finalization ratio, never below the safety minimum.",
    "agent.calibration_finalizing_max_ratio": "Operator ceiling for calibrated finalization ratio, never above the safety maximum.",
    "agent.compression_writeback": "Persist structural context compression back into the loop's message history so append-only frozen segments stay byte-stable across rounds (continuous prefix-cache reuse). Opt-in; the recent raw tail is preserved (default off).",
    "agent.reentry_enabled": "Enable event-driven re-entry: allow tasks to register a resume trigger (schedule_reentry) that seeds a future run from the saved orientation (default off).",
    "agent.reentry_tick_seconds": "How often (seconds) the daemon dispatches due re-entry triggers as isolated subagents (only when reentry is enabled).",
    "agent.reentry_global_budget": "Lifetime cap on total autonomous re-entries per daemon (backstops runaway loops across all triggers; 0 = unlimited).",
    "agent.reentry_send_enabled": "Enable governed autonomous outbound delivery from re-entry: allow a completed re-entry to reply to its originating chat, gated by send-scope Progressive Trust + ApprovalGate (default off; deny-by-default without trust or an approver).",
    "agent.reentry_send_rate_per_hour": "Max autonomous outbound sends per originating chat per hour (0 = unlimited); backstops send storms.",
    "agent.reentry_send_global_budget": "Lifetime cap on total autonomous outbound sends per daemon (0 = unlimited).",
    "agent.reentry_send_verified_at": "Number of human approvals in a send scope before it reaches VERIFIED trust and may be auto-approved (non-destructive replies only).",
    "web.transport": "HTTP transport for web_fetch. auto tries httpx then the system curl; a client refused with 403/429 by one transport is retried on the next. Pin to httpx or curl to make behavior reproducible.",
    "web.timeout_s": "Per-request timeout in seconds for web_fetch.",
    "web.max_bytes": "Response body cap in bytes for web_fetch; larger bodies are truncated and flagged.",
    "web.max_retries": "Retries for rate limits, 5xx, and timeouts. Safe by construction because web_fetch is a read.",
    "web.max_redirects": "Maximum redirects web_fetch will follow before failing.",
    "web.user_agent": "User agent sent by web_fetch. Empty uses a browser-style default, because many CDNs answer 429/403 to library agents; set your own string to identify honestly.",
    "web.extractor": "HTML reader for web_fetch. auto prefers trafilatura when the `web` extra is installed (`pip install 'leapflow[web]'`) and falls back to the built-in stdlib reader; stdlib pins the dependency-free reader.",
    "web.private_targets": "How web_fetch treats URLs resolving to loopback, private, link-local, or cloud-metadata addresses. approval asks the user each session (default), deny refuses without prompting (for unattended deployments), allow permits them silently and is only appropriate on a trusted network.",
    "web.cache_ttl_s": "Seconds a fetched body is reused from the session cache (0 disables caching). Entries are session-scoped and never synced.",
    "usage.pricing": (
        "Per-model token pricing for cost accounting. A YAML/JSON mapping keyed by model "
        "family or exact model name; each value has input_per_mtok, output_per_mtok, and "
        "cached_input_ratio (ratio applied to cached prompt tokens). When absent for the "
        "active model, cost is reported as unknown. Example: "
        '{"deepseek": {"input_per_mtok": 0.27, "output_per_mtok": 1.10, '
        '"cached_input_ratio": 0.1}}'
    ),
    "signal.noise_gate_enabled": "Enable monitor/LeapBoard suppression of low-value signal noise before it wakes watches or enters the live stream.",
    "signal.noise_same_source_cooldown_s": "Suppress repeated fs.change events from the same source path within this many seconds (0 disables burst suppression).",
    "signal.noise_allow_fs_outside_workspace": "Allow fs.change events outside the active workspace into monitor/LeapBoard signal flow (default false to avoid system and unrelated-project churn).",
    "signal.noise_path_fragments": "Path fragments treated as monitor/display noise for fs.change events, e.g. OS caches and tool state directories.",
    "signal.noise_dir_names": "Directory names treated as monitor/display noise for fs.change events.",
    "signal.noise_suffixes": "Filename suffixes treated as transient fs.change noise, e.g. WAL/SHM/journal/temp/log files.",
    "plugins.sandbox_invoke_timeout_s": "Maximum seconds for one Python sandbox RPC; requires daemon restart.",
    "plugins.sandbox_shutdown_timeout_s": "Maximum graceful shutdown wait for a Python sandbox worker; requires daemon restart.",
    "plugins.sandbox_cpu_time_s": "CPU-time ceiling in seconds for each Python sandbox worker; zero disables it.",
    "plugins.sandbox_max_memory_mb": "Address-space ceiling in megabytes for each Python sandbox worker; zero disables it.",
    "plugins.dsh_invoke_timeout_s": "Maximum seconds for one restricted DSH tool invocation; requires daemon restart.",
    "plugins.dsh_discovery_timeout_s": "Maximum seconds for restricted DSH runtime discovery; requires daemon restart.",
    "plugins.dsh_max_message_bytes": "Maximum bytes in one DSH worker NDJSON protocol message; requires daemon restart.",
    "plugins.dsh_max_stderr_bytes": "Bounded diagnostic stderr tail retained from one DSH worker; requires daemon restart.",
    "plugins.dsh_max_memory_mb": "V8 old-space ceiling in megabytes for each DSH worker process; requires daemon restart.",
    "selection.policy": (
        "Which registered policy chooses among tools that provide the same capability. "
        "greedy, the only built-in, takes the highest-scoring candidate. Built-in tools "
        "provide one capability each, so a policy has something to choose between only "
        "once self-evolution has generated a competing tool -- which is why the learning "
        "policies that once shipped here were removed after measurement, and why a "
        "third-party policy can register through the entry point group when that changes."
    ),
    "compression.provider": "Dedicated LLM provider for context compression (empty = reuse primary).",
    "compression.model": "Model for context compression (empty = reuse primary model).",
    "compression.api_key": "API key for the compression provider, stored in the local secret vault.",
    "compression.base_url": "Base URL for the compression provider (empty = reuse primary URL).",
    "compression.protect_first_n": "Number of initial user/assistant exchanges after the system prompt shielded from the first summarization pass.",
    "compression.keep_recent_n": "Minimum recent messages preserved by the SummarizeStage and DropStage compressors.",
    "checkpoint.file_rollback_enabled": "Enable file checkpoint snapshots before mutation tools run, with rollback support via /checkpoint.",
    "checkpoint.max_inline_bytes": "File size threshold in bytes; files larger than this are copied to temp storage instead of stored inline.",
    "checkpoint.ttl_hours": "Hours to retain file checkpoint snapshots before automatic cleanup.",
    "session.resume_cache_policy": (
        "Session resume strategy for PCD cache-aware resumption. 'cache_priority' "
        "restores the persisted tool schema to maximise prefix-cache hits; "
        "'tool_freshness' re-discovers tools at resume time."
    ),
    "evolution.enabled": (
        "Whether the agent may propose acquiring a NEW capability for itself. Off by "
        "default. The world model runs either way: it reviews every session, records what "
        "it learned about your environment for the next one, and recommends which "
        "installed tool to prefer -- none of which writes code. This switch governs the "
        "one branch that does: turning a 'nothing installed can do this' conclusion into a "
        "queued proposal for a new plugin. Queued is not built; generation, validation, "
        "approval, sandboxing and trust all still apply, and every plugin change asks for "
        "your approval individually."
    ),
    "evolution.teacher_poll_interval_s": "Seconds between durable teacher queue polls.",
    "evolution.teacher_lease_s": "Lease duration for one claimed hindsight teacher job.",
    "evolution.teacher_timeout_s": "Maximum seconds for one hindsight teacher call.",
    "evolution.teacher_max_attempts": "Maximum attempts before a teacher job fails permanently.",
    "evolution.teacher_retry_backoff_s": "Base retry delay for failed teacher jobs.",
    "evolution.autonomy_level": "Maximum automatic proposal action; approvals remain mandatory.",
    "environment.mode": "Environment-source mode: production or experiment.",
    "environment.leapspace_enabled": "Enable the LeapSpace filesystem source in experiment mode.",
    "environment.leapspace_state_root": "Host-visible LeapSpace state directory.",
    "environment.leapspace_session_id": "Session receiving LeapSpace environment evidence.",
    "environment.leapspace_poll_interval_s": "Seconds between LeapSpace state scans.",
}

_SECTION_CATEGORIES = {
    # Its own category rather than folded into Learning or Plugins: this is the switch a
    # user is most likely to go looking for, and burying it among tuning knobs would make
    # the most consequential setting the hardest to find.
    "evolution": "Self-Evolution",
    "llm": "LLM Provider",
    "vlm": "Perception",
    "memory": "Memory",
    "visual": "Perception",
    "text": "Perception",
    "clipboard": "Perception",
    "perceptual": "Perception",
    "attention": "Perception",
    "recording": "Recording",
    "video": "Recording",
    "plugins": "Plugins",
    "learnability": "Learning",
    "learn": "Learning",
    "skill": "Skills",
    "hub": "Hub",
    "gateway": "Gateway",
    "privacy": "Safety",
    "approval": "Safety",
    "compression": "LLM Provider",
    "usage": "Usage",
    "session": "Storage",
    "cache": "Storage",
    "runtime": "Runtime",
    "mock": "Runtime",
    "log": "Runtime",
    "scheduler": "Scheduler",
    "dashboard": "Dashboard",
    "monitor": "Dashboard",
    "copilot": "Copilot",
    "react": "Execution Loop",
    "tool": "Execution Loop",
    "context": "Execution Loop",
    "agent": "Execution Loop",
    "guardrail": "Execution Loop",
    "stream": "Interactive UX",
    "verbose": "Interactive UX",
    "signal": "Signal Fusion",
    "surprise": "Signal Fusion",
    "causal": "World Model",
    "prediction": "World Model",
    "curiosity": "World Model",
    "replay": "World Model",
    "web": "Web Access",
}

_VALUE_HINTS = {
    "runtime.log_level": "DEBUG|INFO|WARNING|ERROR",
    "daemon.log_level": "DEBUG|INFO|WARNING|ERROR",
    "mcp.approval_mode": "mutating_only|always|off",
    "hardware.unverified_policy": "deny_write|prompt|allow",
    "hardware.devices_dir": "absolute path, or empty for the profile default",
    "hardware.providers": "comma-separated provider kinds (yaml, host, media)",
    "hardware.host_include": "comma-separated channel-id prefixes, or empty for all",
    "hardware.host_exclude": "comma-separated channel-id prefixes, or empty for none",
    "hardware.skills_enabled": "comma-separated skill-id patterns, or empty for all",
    "recording.mode": "video|default|vision_only",
    "signal.channels": "all or comma-separated channel names",
    "signal.noise_path_fragments": "comma-separated path fragments",
    "signal.noise_dir_names": "comma-separated directory names",
    "signal.noise_suffixes": "comma-separated suffixes",
    "web.transport": "auto|httpx|curl",
    "web.extractor": "auto|stdlib",
    "web.private_targets": "approval|deny|allow",
    "session.resume_cache_policy": "cache_priority|tool_freshness",
    "usage.pricing": "YAML/JSON mapping: {model: {input_per_mtok, output_per_mtok, cached_input_ratio}}",
    # Callable rather than a literal: the valid ids come from the live policy
    # registry, which a third-party package can add to through an entry point. A
    # hardcoded enumeration here would silently omit every such policy and would
    # need editing whenever a built-in is added.
    "selection.policy": lambda: _registered_selection_policies(),
}


def _registered_selection_policies() -> str:
    """The policy ids currently registered, as a hint.

    Degrades to a generic note rather than logging: the only consequence of failure is
    a less specific hint, and this module deliberately carries no logger.
    """
    try:
        from leapflow.plugins.selection_policy_registry import get_selection_policy_registry

        ids = "|".join(d.policy_id for d in get_selection_policy_registry().describe())
    except Exception:  # noqa: BLE001 - a missing hint must not break the catalog
        return "a registered selection policy id"
    return ids or "a registered selection policy id"


_PARTIAL_RELOAD_SECTIONS = frozenset(
    {
        "runtime",
        "mock",
        "gateway",
        "hub",
        "scheduler",
        "observer",
        "cua",
        "use",
        "usage",
        "dashboard",
    }
)
_RESTART_REQUIRED_SECTIONS = frozenset({"daemon", "plugins", "hardware", "mcp"})

_PROFILE_FILE_BY_SECTION = {
    "llm": "llm.yaml",
    "hub": "hub.yaml",
    "gateway": "gateway.yaml",
    "privacy": "privacy.yaml",
    "approval": "approval.yaml",
    "compression": "llm.yaml",
    "usage": "llm.yaml",
    "checkpoint": "runtime.yaml",
    "cache": "cache.yaml",
}

_PERCEPTION_SECTIONS = frozenset(
    {
        "visual",
        "vlm",
        "text",
        "clipboard",
        "perceptual",
        "attention",
        "recording",
        "causal",
        "heuristic",
        "prediction",
        "curiosity",
        "replay",
        "semantic",
        "budget",
        "ast",
        "mhms",
        "surprise",
        "video",
        "learnability",
        "signal",
    }
)

_EXPLICIT_SPECS = {
    "llm_api_key": ConfigFieldSpec(
        "llm.api_key",
        "llm",
        "api_key_ref",
        str,
        "llm.yaml",
        setting_name="llm_api_key",
        scopes=("profile",),
        secret=True,
        ref_name="llm/primary/api_key",
    ),
    "mock_host": ConfigFieldSpec(
        "runtime.mock_host",
        "mock",
        "host",
        bool,
        "runtime.yaml",
        setting_name="mock_host",
    ),
    "log_level": ConfigFieldSpec(
        "runtime.log_level",
        "log",
        "level",
        str,
        "runtime.yaml",
        setting_name="log_level",
    ),
}


def _build_field_specs() -> dict[str, ConfigFieldSpec]:
    type_hints = get_type_hints(Settings)
    specs: dict[str, ConfigFieldSpec] = {}
    for item in fields(Settings):
        name = item.name
        if name in _BOOTSTRAP_ONLY_SETTINGS:
            continue
        if name in _EXPLICIT_SPECS:
            spec = _EXPLICIT_SPECS[name]
        else:
            spec = _spec_from_setting(name, type_hints.get(name, item.type))
            if spec is None:
                continue
        spec = _with_metadata(spec)
        specs[spec.key] = spec
    return dict(sorted(specs.items()))


def _spec_from_setting(name: str, value_type: Any) -> ConfigFieldSpec | None:
    parts = name.split("_", 1)
    if len(parts) == 1:
        return None
    section, field_name = parts
    if section == "llm" and field_name == "api_key":
        return None
    if name in _SECRET_SETTINGS:
        return ConfigFieldSpec(
            key=f"{section}.{field_name}",
            section=section,
            name=f"{field_name}_ref",
            value_type=str,
            profile_file=_profile_file_for_section(section),
            setting_name=name,
            scopes=("profile",),
            secret=True,
            ref_name=f"{section}/{field_name}",
        )
    return ConfigFieldSpec(
        key=f"{section}.{field_name}",
        section=section,
        name=field_name,
        value_type=value_type,
        profile_file=_profile_file_for_section(section),
        setting_name=name,
    )


def _profile_file_for_section(section: str) -> str:
    if section in _PROFILE_FILE_BY_SECTION:
        return _PROFILE_FILE_BY_SECTION[section]
    if section in _PERCEPTION_SECTIONS:
        return "perception.yaml"
    return "runtime.yaml"


class ConfigService:
    """Read and mutate LeapFlow configuration through layout-owned paths."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._secrets = ScopedSecretResolver(settings.layout, settings.profile_layout)

    def snapshot(self) -> ConfigSnapshot:
        values = tuple(self.get(key) for key in sorted(_FIELD_SPECS))
        return ConfigSnapshot(
            values=values,
            sources=tuple(self._settings.config_sources),
            warnings=tuple(self._settings.config_warnings),
        )

    def sources(self) -> tuple[str, ...]:
        return tuple(self._settings.config_sources)

    def writable_keys(self) -> tuple[str, ...]:
        return tuple(sorted(_FIELD_SPECS))

    def describe(self, key: str) -> ConfigFieldView:
        """Return metadata and effective value for one writable config field."""
        normalized = _normalize_key(key)
        spec = _FIELD_SPECS.get(normalized)
        if spec is None:
            raise ValueError(f"Unknown config key: {key}")
        return self._field_view(spec)

    def list_fields(self, category: str | None = None) -> tuple[ConfigFieldView, ...]:
        """List writable config fields with human-readable metadata."""
        normalized = category.strip().lower() if category else ""
        fields_list = []
        for spec in _FIELD_SPECS.values():
            if (
                normalized
                and normalized not in spec.category.lower()
                and not spec.key.lower().startswith(f"{normalized}.")
            ):
                continue
            fields_list.append(self._field_view(spec))
        return tuple(sorted(fields_list, key=lambda item: (item.category, item.key)))

    def get(self, key: str) -> ConfigValueView:
        normalized = _normalize_key(key)
        spec = _FIELD_SPECS.get(normalized)
        if spec is None:
            raise ValueError(f"Unknown config key: {key}")
        if spec.secret:
            value = str(getattr(self._settings, spec.setting_name or "", "") or "")
            return ConfigValueView(normalized, _mask_secret(value), secret=True)
        value = getattr(self._settings, spec.setting_name or "", None)
        return ConfigValueView(normalized, _format_value(value), secret=False)

    def set(
        self, key: str, value: object, *, scope: ConfigScope = "profile"
    ) -> ConfigMutationResult:
        normalized = _normalize_key(key)
        spec = _FIELD_SPECS.get(normalized)
        if spec is None:
            raise ValueError(f"Unsupported config key: {key}")
        if scope not in spec.scopes:
            raise ValueError(f"Config key {normalized} does not support scope: {scope}")
        if spec.secret:
            return self._set_secret_backed_field(spec, str(value), scope=scope)
        coerced = _coerce_value(value, spec.value_type)
        path = self._path_for_spec(spec, scope)
        data = _read_yaml(path)
        section = dict(data.get(spec.section) or {})
        section[spec.name] = coerced
        data[spec.section] = section
        _write_yaml_atomic(path, data)
        return ConfigMutationResult(
            True,
            f"Updated {normalized}",
            (normalized,),
            path,
            _restart_warnings(spec),
        )

    def unset(self, key: str, *, scope: ConfigScope = "profile") -> ConfigMutationResult:
        normalized = _normalize_key(key)
        spec = _FIELD_SPECS.get(normalized)
        if spec is None:
            raise ValueError(f"Unsupported config key: {key}")
        if scope not in spec.scopes:
            raise ValueError(f"Config key {normalized} does not support scope: {scope}")
        path = self._path_for_spec(spec, scope)
        data = _read_yaml(path)
        section = dict(data.get(spec.section) or {})
        section.pop(spec.name, None)
        data[spec.section] = section
        _write_yaml_atomic(path, data)
        return ConfigMutationResult(
            True,
            f"Unset {normalized}",
            (normalized,),
            path,
            _restart_warnings(spec),
        )

    def configure_llm(
        self,
        *,
        api_key: str | None = None,
        ask_api_key: bool = False,
        base_url: str | None = None,
        model: str | None = None,
        context_length: int | None = None,
        max_retries: int | None = None,
        scope: ConfigScope = "profile",
    ) -> ConfigMutationResult:
        changed: list[str] = []
        path: Path | None = None
        if ask_api_key:
            api_key = getpass("LLM API key: ")
        if api_key is not None:
            result = self.set("llm.api_key", api_key, scope=scope)
            changed.extend(result.changed_keys)
            path = result.path
        for key, item in (
            ("llm.base_url", base_url.rstrip("/") if base_url is not None else None),
            ("llm.model", model),
            ("llm.context_length", context_length),
            ("llm.max_retries", max_retries),
        ):
            if item is None:
                continue
            result = self.set(key, item, scope=scope)
            changed.extend(result.changed_keys)
            path = result.path
        if not changed:
            return ConfigMutationResult(False, "No LLM config changes requested", (), path)
        return ConfigMutationResult(True, "LLM config updated", tuple(dict.fromkeys(changed)), path)

    def list_secrets(self) -> tuple[str, ...]:
        return self._secrets.list_refs()

    def set_secret(
        self,
        ref: str,
        value: str | None = None,
        *,
        scope: SecretScope = "profile",
        reveal_name: bool = True,
    ) -> ConfigMutationResult:
        normalized = normalize_secret_ref(ref, default_scope=scope)
        secret_value = value if value is not None else getpass(f"Value for {normalized}: ")
        self._secrets.set(normalized, secret_value, metadata={"source": "config"})
        name = normalized if reveal_name else "secret"
        return ConfigMutationResult(True, f"Saved {name}", (normalized,))

    def get_secret(self, ref: str, *, scope: SecretScope = "profile", reveal: bool = False) -> str:
        normalized = normalize_secret_ref(ref, default_scope=scope)
        value = self._secrets.get(normalized)
        if value is None:
            raise KeyError(normalized)
        return value if reveal else f"{normalized} is set"

    def delete_secret(self, ref: str, *, scope: SecretScope = "profile") -> ConfigMutationResult:
        normalized = normalize_secret_ref(ref, default_scope=scope)
        self._secrets.delete(normalized)
        return ConfigMutationResult(True, f"Deleted {normalized}", (normalized,))

    def _set_secret_backed_field(
        self,
        spec: ConfigFieldSpec,
        value: str,
        *,
        scope: ConfigScope,
    ) -> ConfigMutationResult:
        secret_path = spec.ref_name or spec.key.replace(".", "/")
        ref = secret_ref("profile", *[part for part in secret_path.split("/") if part])
        self._secrets.set(ref, value, metadata={"source": "config", "owner": spec.section})
        path = self._path_for_spec(spec, scope)
        data = _read_yaml(path)
        section = dict(data.get(spec.section) or {})
        section[spec.name] = ref
        data[spec.section] = section
        _write_yaml_atomic(path, data)
        return ConfigMutationResult(
            True, f"Updated {spec.key}", (spec.key, f"{spec.key}_ref"), path
        )

    def _path_for_spec(self, spec: ConfigFieldSpec, scope: ConfigScope) -> Path:
        if scope == "profile":
            return self._settings.profile_layout.config_dir / spec.profile_file
        if scope == "workspace":
            return self._settings.layout.workspace_config_path(self._settings.workspace_root)
        if scope == "user":
            return self._settings.layout.user_config_path
        raise ValueError(f"Unsupported config scope: {scope}")

    def _field_view(self, spec: ConfigFieldSpec) -> ConfigFieldView:
        value = self.get(spec.key)
        return ConfigFieldView(
            key=spec.key,
            value=value.value,
            value_type="secret" if spec.secret else _type_label(spec.value_type),
            category=spec.category,
            scopes=tuple(spec.scopes),
            hot_reload=spec.hot_reload,
            secret=spec.secret,
            description=spec.description,
            value_hint=spec.value_hint,
            examples=spec.examples,
        )


def _with_metadata(spec: ConfigFieldSpec) -> ConfigFieldSpec:
    if spec.section in _RESTART_REQUIRED_SECTIONS:
        reload_semantics = "restart-required"
    elif spec.section in _PARTIAL_RELOAD_SECTIONS:
        reload_semantics = "partial"
    else:
        reload_semantics = "yes"
    hint = _VALUE_HINTS.get(spec.key, None)
    if hint is None:
        hint = _default_value_hint(spec)
    elif callable(hint):
        hint = hint()
    return replace(
        spec,
        category=_category_for_spec(spec),
        description=_FIELD_DESCRIPTIONS.get(spec.key, _default_description(spec.key)),
        value_hint=str(hint),
        hot_reload=reload_semantics,
        examples=_examples_for_key(spec.key),
    )


def _restart_warnings(spec: ConfigFieldSpec) -> tuple[str, ...]:
    if spec.hot_reload != "restart-required":
        return ()
    return (
        f"{spec.key} requires `leap daemon restart` to take effect; "
        "the running leapd keeps its previous value until restarted.",
    )


def _category_for_spec(spec: ConfigFieldSpec) -> str:
    # Compression protect/keep settings are behavioural context controls,
    # not LLM-provider knobs, so they belong under Execution Loop.
    if spec.key in (
        "compression.protect_first_n",
        "compression.keep_recent_n",
    ):
        return "Execution Loop"
    if spec.key.startswith("checkpoint."):
        return "Execution Loop"
    if spec.key.startswith("runtime."):
        return "Runtime"
    return _SECTION_CATEGORIES.get(spec.section, _title_words(spec.section))


def _default_description(key: str) -> str:
    words = key.replace(".", " ").replace("_", " ")
    return f"Configure {words}."


def _default_value_hint(spec: ConfigFieldSpec) -> str:
    value_type = _unwrap_optional(spec.value_type)
    origin = get_origin(value_type)
    if spec.secret:
        return "secret value"
    if value_type is bool:
        return "true|false"
    if value_type in (tuple, list, frozenset) or origin in (tuple, list, frozenset):
        return "comma-separated values"
    if value_type is dict or origin is dict:
        return "YAML/JSON mapping"
    return ""


def _examples_for_key(key: str) -> tuple[str, ...]:
    examples = {
        "llm.model": ("leap config set llm.model qwen3.7-plus",),
        "llm.context_length": ("leap config set llm.context_length 1000000",),
        "runtime.mock_host": ("leap config set runtime.mock_host true",),
        "runtime.log_level": ("leap config set runtime.log_level DEBUG",),
        "memory.working_max_tokens": ("leap config set memory.working_max_tokens 0",),
        "visual.track_enabled": ("leap config set visual.track_enabled true",),
    }
    return examples.get(key, ())


def _title_words(value: str) -> str:
    return " ".join(part.capitalize() for part in value.replace("_", " ").split())


def _type_label(value_type: Any) -> str:
    normalized = _unwrap_optional(value_type)
    origin = get_origin(normalized)
    if normalized in (str, int, float, bool):
        return normalized.__name__
    if normalized is Path:
        return "path"
    if normalized is dict or origin is dict:
        return "dict"
    if normalized in (tuple, list, frozenset) or origin in (tuple, list, frozenset):
        return "list"
    if origin is Literal:
        return "|".join(str(item) for item in get_args(normalized))
    return getattr(normalized, "__name__", str(normalized).replace("typing.", ""))


def _unwrap_optional(value_type: Any) -> Any:
    origin = get_origin(value_type)
    if origin in (UnionType, Union):
        args = tuple(arg for arg in get_args(value_type) if arg is not type(None))
        if len(args) == 1:
            return args[0]
    return value_type


_FIELD_SPECS: dict[str, ConfigFieldSpec] = _build_field_specs()


def normalize_secret_ref(raw: str, *, default_scope: SecretScope = "profile") -> str:
    """Normalize a CLI/TUI secret shorthand into a secret:// ref."""
    value = raw.strip()
    if value.startswith("secret://"):
        secret_scope(value)
        return value
    return secret_ref(default_scope, *_secret_name_parts(value))


def _secret_name_parts(value: str) -> list[str]:
    if "/" in value:
        parts = [part for part in value.split("/") if part]
    else:
        parts = [part for part in value.split(".") if part]
    if not parts:
        raise ValueError("Secret ref cannot be empty")
    return parts


def _normalize_key(key: str) -> str:
    value = key.strip()
    if value.startswith("LEAPFLOW_"):
        parts = value[len("LEAPFLOW_") :].lower().split("_", 1)
        return parts[0] if len(parts) == 1 else f"{parts[0]}.{parts[1]}"
    if "_" in value and "." not in value:
        parts = value.lower().split("_", 1)
        return f"{parts[0]}.{parts[1]}"
    return value


def _coerce_value(value: object, value_type: Any) -> object:
    value_type = _unwrap_optional(value_type)
    origin = get_origin(value_type)
    if origin in (tuple, list, frozenset) or value_type in (tuple, list, frozenset):
        if isinstance(value, (list, tuple, set, frozenset)):
            return list(value)
        return [part.strip() for part in str(value).split(",") if part.strip()]
    if origin is dict or value_type is dict:
        parsed = yaml.safe_load(str(value))
        if not isinstance(parsed, dict):
            raise ValueError(f"Expected mapping value, got: {value}")
        return parsed
    if value_type is bool:
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in {"1", "true", "yes", "on"}:
            return True
        if text in {"0", "false", "no", "off"}:
            return False
        raise ValueError(f"Expected boolean value, got: {value}")
    if value_type is int:
        return int(str(value).strip())
    if value_type is float:
        return float(str(value).strip())
    if value_type is Path:
        return str(value).strip()
    if value_type is str:
        return str(value).strip()
    text = str(value).strip()
    if text.startswith("{") or text.startswith("["):
        return yaml.safe_load(text)
    return text


def _mask_secret(raw: str) -> str:
    """Render a secret as a masked hint (e.g. ``***3ab``), never the full value.

    Empty secrets render as ``missing``; short values are fully masked.
    """
    text = str(raw or "").strip()
    if not text:
        return "missing"
    # Reveal the last 3 chars only for secrets long enough that the suffix leaves
    # ample entropy masked; short secrets (< 16 chars) are fully masked.
    suffix = text[-3:] if len(text) >= 16 else ""
    return f"***{suffix}" if suffix else "***"


def _format_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (tuple, list, set, frozenset)):
        return ",".join(str(item) for item in value)
    if isinstance(value, dict):
        return yaml.safe_dump(value, sort_keys=True, default_flow_style=True).strip()
    return "" if value is None else str(value)


def _read_yaml(path: Path) -> dict[str, Any]:
    try:
        loaded = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError, ValueError):
        return {"version": 1}
    if not isinstance(loaded, dict):
        return {"version": 1}
    loaded.setdefault("version", 1)
    return dict(loaded)


def _write_yaml_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            yaml.safe_dump(data, handle, sort_keys=False, allow_unicode=True)
        os.replace(tmp_path, path)
        if os.name != "nt":
            path.chmod(0o600)
    except Exception:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise
