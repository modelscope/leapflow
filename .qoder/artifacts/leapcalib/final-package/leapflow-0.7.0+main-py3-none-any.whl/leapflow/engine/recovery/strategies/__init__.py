# Copyright (c) Alibaba, Inc. and its affiliates.
"""Built-in recovery strategies for the agent loop recovery coordinator.

Each strategy implements the RecoveryStrategy Protocol and encapsulates
a single-responsibility recovery pattern (context compression, failover,
credential rotation, etc.).
"""
from __future__ import annotations

from leapflow.engine.recovery.strategies.compression_timeout import CompressionTimeoutStrategy
from leapflow.engine.recovery.strategies.context_compress import ContextCompressStrategy
from leapflow.engine.recovery.strategies.credential_rotate import CredentialRotateStrategy
from leapflow.engine.recovery.strategies.jittered_retry import JitteredRetryStrategy
from leapflow.engine.recovery.strategies.multimodal_strip import MultimodalStripStrategy
from leapflow.engine.recovery.strategies.native_to_text import NativeToTextFallbackStrategy
from leapflow.engine.recovery.strategies.provider_failover import ProviderFailoverStrategy
from leapflow.engine.recovery.strategies.thinking_disable import ThinkingDisableStrategy
from leapflow.engine.recovery.strategies.tool_schema_expand import ToolSchemaExpandStrategy

__all__ = [
    "CompressionTimeoutStrategy",
    "ContextCompressStrategy",
    "CredentialRotateStrategy",
    "JitteredRetryStrategy",
    "MultimodalStripStrategy",
    "NativeToTextFallbackStrategy",
    "ProviderFailoverStrategy",
    "ThinkingDisableStrategy",
    "ToolSchemaExpandStrategy",
    "default_strategies",
]


def default_strategies(credential_availability=None) -> list:
    """Return all built-in strategies in priority order (lowest priority number first).

    ``credential_availability`` (typically the active ``FailoverChain``) lets
    ``CredentialRotateStrategy`` bow out when no rotatable credential remains,
    so provider failover takes over instead of looping.
    """
    return [
        ContextCompressStrategy(),
        CompressionTimeoutStrategy(),
        MultimodalStripStrategy(),
        ProviderFailoverStrategy(),
        CredentialRotateStrategy(credential_availability=credential_availability),
        ThinkingDisableStrategy(),
        NativeToTextFallbackStrategy(),
        ToolSchemaExpandStrategy(),
        JitteredRetryStrategy(),
    ]
